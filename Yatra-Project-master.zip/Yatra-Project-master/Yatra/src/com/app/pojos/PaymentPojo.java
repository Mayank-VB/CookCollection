package com.app.pojos;

public class PaymentPojo {
//paymentId, cartId,amount,payment date
	
//booking id,
}
