package com.app.pojos;

public class CartPojo {
//cart id,package id, price,tax,
}
