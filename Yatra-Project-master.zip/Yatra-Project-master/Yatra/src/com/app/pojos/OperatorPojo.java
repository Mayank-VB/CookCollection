package com.app.pojos;

public class OperatorPojo {

}
